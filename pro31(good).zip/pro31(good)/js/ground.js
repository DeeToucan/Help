class Ground{
    constructor(x,y,w,h) {
      var options = {
          isStatic: true
      }
      this.body = Bodies.rectangle(x,y,w,h,options);
      this.w = w; 
      this.h = h;
      this.r = 255;
      this.g = 255;
      this.b = 255;
      World.add(world, this.body);
    }

    changeColor(r,g,b){
      this.r = r;
      this.g = g;
      this.b = b;
    }
    display(){
      var pos =this.body.position;
      rectMode(CENTER);
      fill(this.r,this.g,this.b);
      noStroke();
      rect(pos.x, pos.y, this.w,this.h);
    }
  };