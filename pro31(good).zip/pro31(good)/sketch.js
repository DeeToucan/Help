var Engine = Matter.Engine,
  World = Matter.World,
  Events = Matter.Events,
  Bodies = Matter.Bodies;

var g;
var dG = [];
var pG = [];
var prtG = [];

function setup() {
  createCanvas(800, 800);
  engine = Engine.create();
  world = engine.world;

  for (var i = 0; i <= width; i = i + 80){
    dG.push(new Ground(i, height - 150, 10, 300));
  }

  for (var i = 40; i <= width; i = i + 50){
    pG.push(new Plinko(i, 75));
  }

  for (var i = 15; i <= width - 10; i = i + 50){
    pG.push(new Plinko(i, 175));
  }


  // dG.push(d1,d2,d3,d4,d5,d6,d7);
  g = new Ground(400,790,width,20);

  
}
 


function draw() {
  background("black");
  g.changeColor(123,123,123);

  if (frameCount % 60 === 0){
    prtG.push(new Particle(random(200, 600),10,10));
  }

  for (var i = 0; i < dG.length; i++){
    dG[i].changeColor(123,123,123);
    dG[i].display();
  }

  for (var i = 0; i < pG.length; i++){
    pG[i].display();
  }

  for (var i = 0; i < prtG.length; i++) {
     
    prtG[i].display();
  }

  g.display();
}

